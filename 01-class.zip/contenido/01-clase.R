# Codigo 1: Herramientas asociadas a R ------------------------------------

# Los gatos ( # ) son comentarios
# Para hacer una division en el código CTRL+ Shift + R

# Para guardar el script CTRL + S (archivo.R)

# 0. Algunos ejercicios de ejemplo------------------------------------------
print("Hello world")

# 1. Cargar paquetes ------------------------------------------------------
# Sesion 2

# 2. Cargar datos ---------------------------------------------------------
# Sesion 3
read.csv("datos/datos.csv")
datos <- read.csv("datos/datos.csv")
str(datos)

# 3. Procesar datos -------------------------------------------------------
# Sesion 4 en adelante

# 4. Guardar datos --------------------------------------------------------


