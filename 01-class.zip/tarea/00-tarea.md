## Tarea 0

Luego de leer esta breve introducción, debes contestar esta guía:

1. ¿Cuál es tu nombre?

R:

2. ¿Cuál es la diferencia entre R y RStudio?

R:

3. ¿Con qué comando puedes subir los cambios del repositorio local al remoto?

R:

4. Crea un .Rproject llamado 00-tarea.Rproject

5. En el repositorio, crea una carpeta llamada “imagenes”. Dentro de esta carpeta deja una imagen de tu sociólogo/a o cientista social preferido/a. Al archivo debes llamarlo “sociologo-preferido.jpg”